package cmd

import (
	"context"
	"fmt"
	"os"

	"github.com/ahmedfawzy/devops-toolkit/pkg/aws"
	"github.com/ahmedfawzy/devops-toolkit/pkg/reporter"
	"github.com/spf13/cobra"
)

var (
	awsRegion     string
	outputFormat  string
	includeEC2    bool
	includeEBS    bool
	includeSnaps  bool
)

var awsCmd = &cobra.Command{
	Use:   "aws",
	Short: "AWS resource auditing and optimization",
	Long:  "Audit AWS resources to identify waste and optimization opportunities",
}

var awsAuditCmd = &cobra.Command{
	Use:   "audit",
	Short: "Audit AWS resources for waste",
	Long: `Scan your AWS account for wasteful resources:
	
- Unattached EBS volumes
- Underutilized EC2 instances (< 5% CPU)
- Orphaned EBS snapshots
- Unused Elastic IPs

Example:
  dtk aws audit --region us-east-1
  dtk aws audit --region eu-west-1 --format json
  dtk aws audit --ebs-only`,
	RunE: runAWSAudit,
}

func init() {
	rootCmd.AddCommand(awsCmd)
	awsCmd.AddCommand(awsAuditCmd)

	awsAuditCmd.Flags().StringVarP(&awsRegion, "region", "r", "", "AWS region (defaults to AWS_REGION env var)")
	awsAuditCmd.Flags().StringVarP(&outputFormat, "format", "f", "table", "Output format: table, json, csv")
	awsAuditCmd.Flags().BoolVar(&includeEC2, "ec2", true, "Include EC2 instance analysis")
	awsAuditCmd.Flags().BoolVar(&includeEBS, "ebs", true, "Include EBS volume analysis")
	awsAuditCmd.Flags().BoolVar(&includeSnaps, "snapshots", true, "Include snapshot analysis")
}

func runAWSAudit(cmd *cobra.Command, args []string) error {
	ctx := context.Background()

	// Use environment variable if region not specified
	if awsRegion == "" {
		awsRegion = os.Getenv("AWS_REGION")
		if awsRegion == "" {
			awsRegion = "us-east-1"
		}
	}

	fmt.Printf("🔍 Auditing AWS resources in region: %s\n\n", awsRegion)

	auditor, err := aws.NewAuditor(ctx, awsRegion)
	if err != nil {
		return fmt.Errorf("failed to create AWS auditor: %w", err)
	}

	results := &aws.AuditResults{}

	// Audit EBS volumes
	if includeEBS {
		fmt.Println("📦 Checking EBS volumes...")
		volumes, err := auditor.FindUnattachedVolumes(ctx)
		if err != nil {
			return fmt.Errorf("failed to audit EBS volumes: %w", err)
		}
		results.UnattachedVolumes = volumes
	}

	// Audit EC2 instances
	if includeEC2 {
		fmt.Println("💻 Checking EC2 instances...")
		instances, err := auditor.FindUnderutilizedInstances(ctx)
		if err != nil {
			return fmt.Errorf("failed to audit EC2 instances: %w", err)
		}
		results.UnderutilizedInstances = instances
	}

	// Audit snapshots
	if includeSnaps {
		fmt.Println("📸 Checking EBS snapshots...")
		snapshots, err := auditor.FindOrphanedSnapshots(ctx)
		if err != nil {
			return fmt.Errorf("failed to audit snapshots: %w", err)
		}
		results.OrphanedSnapshots = snapshots
	}

	// Calculate potential savings
	results.CalculateSavings()

	fmt.Println()

	// Output results
	rep := reporter.NewReporter(outputFormat)
	if err := rep.RenderAuditResults(results); err != nil {
		return fmt.Errorf("failed to render results: %w", err)
	}

	return nil
}
